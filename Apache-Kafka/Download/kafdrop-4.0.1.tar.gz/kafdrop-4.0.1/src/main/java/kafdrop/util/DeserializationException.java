package kafdrop.util;

public class DeserializationException extends RuntimeException {
  /**
   *
   */
  private static final long serialVersionUID = -2575341690419824332L;

  public DeserializationException(String msg) {
    super(msg);
  }
}
