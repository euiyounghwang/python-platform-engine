package kafdrop.util;

public enum MessageFormat {
  DEFAULT, AVRO, PROTOBUF, MSGPACK
}
